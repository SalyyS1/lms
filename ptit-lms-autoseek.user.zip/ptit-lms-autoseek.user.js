// ==UserScript==
// @name         PTIT LMS Auto-Complete Pro Max
// @namespace    http://tampermonkey.net/
// @version      1.0.0
// @description  Tự động hoàn thành video LMS PTIT và dò đáp án ẩn trên hệ thống thẻ Open edX (với rủi ro 1 attempt).
// @author       Antigravity
// @match        https://lms.ptit.edu.vn/*
// @grant        none
// ==UserScript==

(function() {
    'use strict';

    // ==========================================
    // 1. CORE LOGIC: YOUTUBE BYPASS (From repo)
    // ==========================================
    let patchedBind = false;
    let originalSeekTo = null;

    function patchYTPlayer() {
        if (!(window.YT && YT.Player && YT.Player.prototype)) return false;
        const proto = YT.Player.prototype;
        if (!proto.__ptit_seek_block__) {
            originalSeekTo = proto.seekTo;
            // Vô hiệu hóa hàm seekTo để LMS/Moodle không thể giật lùi video khi bạn tua
            proto.seekTo = function(...args) {
                // Ta chặn gọi từ hệ thống, nhưng script của ta sẽ dùng originalSeekTo
            };
            proto.__ptit_seek_block__ = true;
        }
        return true;
    }

    function hookBind() {
        if (patchedBind) return;
        const orig = Function.prototype.bind;
        Function.prototype.bind = function (thisArg, ...args) {
            try {
                if (!patchedBind && thisArg && typeof this.name === "string" && this.name.includes("_onPlayerStateChange")) {
                    if (typeof thisArg._checkCurrentTime === "function") {
                        thisArg._checkCurrentTime = () => 1; // Báo cáo luôn hợp lệ
                    }
                    const proto = Object.getPrototypeOf(thisArg);
                    if (proto && typeof proto._checkCurrentTime === "function") {
                        proto._checkCurrentTime = () => 1;
                    }
                    patchedBind = true;
                    // Restore original
                    Function.prototype.bind = orig;
                }
            } catch (e) {}
            return orig.apply(this, [thisArg, ...args]);
        };
    }

    function unlockSeekEngine() {
        hookBind();
        if (!patchYTPlayer()) {
            const oldReady = window.onYouTubeIframeAPIReady;
            window.onYouTubeIframeAPIReady = () => {
                try { patchYTPlayer(); } catch (e) {}
                if (typeof oldReady === "function") oldReady();
            };
        }
        let tries = 0;
        const timer = setInterval(() => {
            tries++;
            if (patchYTPlayer() || tries > 40) clearInterval(timer);
        }, 250);
    }

    // Initialize the bypass as early as possible
    unlockSeekEngine();

    // ==========================================
    // 2. MAIN ACTIONS: AUTO-COMPLETE & SOLVER
    // ==========================================
    function logMsg(msg, isErr=false) {
        const consoleLog = isErr ? console.error : console.log;
        consoleLog(`%c[PTIT LMS Tool]%c ${msg}`, 'color: #ff0055; font-weight: bold;', 'color: inherit;');
        alert(`[PTIT LMS] ${msg}`);
    }

    function autoFinishVideos() {
        const iframes = document.querySelectorAll('iframe[src*="youtube.com"]');
        if (iframes.length === 0) {
            logMsg("Không tìm thấy video YouTube nào trên trang này!", true);
            return;
        }

        let completed = 0;
        iframes.forEach(iframe => {
            // Sử dụng PostMessage API ẩn của Youtube để buộc video chuyển đến 99% thời lượng
            // (1 giây trước khi kết thúc) để kích hoạt event 'ENDED' thật hoàn hảo cho Server PTIT
            iframe.contentWindow.postMessage(JSON.stringify({
                event: 'command',
                func: 'seekTo',
                args: [9999, true]
            }), '*');

            iframe.contentWindow.postMessage(JSON.stringify({
                event: 'command',
                func: 'playVideo',
                args: []
            }), '*');
            completed++;
        });

        logMsg(`Đã ra lệnh Tua sát & Hoàn thành cho ${completed} video.`);
    }

    function scanForHiddenAnswers() {
        // LMS PTIT chạy trên Open edX.
        // Hầu hết Quiz Open edX sẽ giấu đáp án ở thẻ .solution-span hoặc .problem
        let found = false;
        const solutions = document.querySelectorAll('.solution-span, .capa_solution');
        
        if (solutions.length > 0) {
            solutions.forEach((sol, index) => {
                sol.style.display = 'block'; // Hiển thị ép buộc
                sol.style.backgroundColor = '#ffffcc';
                sol.style.border = '2px dashed red';
                sol.style.padding = '10px';
                sol.style.marginTop = '10px';
                sol.innerHTML = `<b>Đáp án ${index + 1}:</b><br>` + sol.innerHTML;
            });
            logMsg(`TUYỆT VỜI! Đã tìm thấy và bóc mẽ ${solutions.length} khối đáp án bị ẩn trong mã nguồn HTML.`);
            found = true;
            return;
        }

        // Cách 2: Tìm thử qua data attributes
        const labels = document.querySelectorAll('label, input');
        // Quét nhưng không bruteforce vì giới hạn 1 Attempt
        const problemBlocks = document.querySelectorAll('.problems-wrapper, .problem');
        if (problemBlocks.length > 0 && !found) {
            logMsg("CẢNH BÁO MỖI BÀI CHỈ ĐƯỢC 1 LẦN NỘP (1 Attempt)!\n\nBài tập này được bảo mật 100% Server-side. KHÔNG dùng tool điền bừa để tránh bị 0 điểm. Hãy tự làm!", true);
        } else if (!found) {
            logMsg("Không tìm thấy Box Bài tập (Quiz) nào trên trang.", true);
        }
    }

    // ==========================================
    // 3. UI: FLOATING DASHBOARD
    // ==========================================
    function initUI() {
        const container = document.createElement('div');
        container.style.position = 'fixed';
        container.style.bottom = '20px';
        container.style.right = '20px';
        container.style.zIndex = '999999';
        container.style.backgroundColor = 'rgba(25, 25, 25, 0.95)';
        container.style.border = '1px solid #444';
        container.style.borderRadius = '8px';
        container.style.padding = '15px';
        container.style.boxShadow = '0 10px 25px rgba(0,0,0,0.5)';
        container.style.fontFamily = 'Arial, sans-serif';
        container.style.color = '#fff';
        container.style.width = '220px';

        const title = document.createElement('div');
        title.innerHTML = '🎓 <b>PTIT LMS PRO MAX</b>';
        title.style.marginBottom = '10px';
        title.style.fontSize = '14px';
        title.style.textAlign = 'center';
        container.appendChild(title);

        const btnVideo = document.createElement('button');
        btnVideo.innerText = '⏭️ Tự Động Xong Video';
        btnVideo.style.width = '100%';
        btnVideo.style.padding = '8px';
        btnVideo.style.marginBottom = '10px';
        btnVideo.style.backgroundColor = '#e11d48';
        btnVideo.style.color = 'white';
        btnVideo.style.border = 'none';
        btnVideo.style.borderRadius = '5px';
        btnVideo.style.cursor = 'pointer';
        btnVideo.style.fontWeight = 'bold';
        btnVideo.onclick = autoFinishVideos;
        
        btnVideo.onmouseover = () => btnVideo.style.backgroundColor = '#be123c';
        btnVideo.onmouseout = () => btnVideo.style.backgroundColor = '#e11d48';
        container.appendChild(btnVideo);

        const btnQuiz = document.createElement('button');
        btnQuiz.innerText = '🔍 Scan Đáp Án (Quiz)';
        btnQuiz.style.width = '100%';
        btnQuiz.style.padding = '8px';
        btnQuiz.style.backgroundColor = '#0284c7';
        btnQuiz.style.color = 'white';
        btnQuiz.style.border = 'none';
        btnQuiz.style.borderRadius = '5px';
        btnQuiz.style.cursor = 'pointer';
        btnQuiz.style.fontWeight = 'bold';
        btnQuiz.onclick = scanForHiddenAnswers;

        btnQuiz.onmouseover = () => btnQuiz.style.backgroundColor = '#0369a1';
        btnQuiz.onmouseout = () => btnQuiz.style.backgroundColor = '#0284c7';
        container.appendChild(btnQuiz);

        const footer = document.createElement('div');
        footer.innerHTML = '<small>Bảo vệ 1 Attempt Limit</small>';
        footer.style.marginTop = '10px';
        footer.style.fontSize = '10px';
        footer.style.color = '#888';
        footer.style.textAlign = 'center';
        container.appendChild(footer);

        document.body.appendChild(container);
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        initUI();
    } else {
        document.addEventListener('DOMContentLoaded', initUI);
    }
})();
